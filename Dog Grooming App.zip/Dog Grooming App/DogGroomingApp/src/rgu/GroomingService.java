/*
 * Description: this is the GroomingService.java class.
 * the class extends Service.java abstract class.
 * The GroomingService class  includes custom style grooming.
 * Created Date: 2021-07-02
 */
package rgu;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class GroomingService extends Service {
    //creating instance variables
    private final String customStyle;
    private double customStyleCost;
    
    //constructor method for the class
    public GroomingService(String customStyle, double customStyleCost, String description, Groomer groomer, double cost){
        super(description, groomer, cost);
        this.customStyle = customStyle;
        this.customStyleCost = customStyleCost;
    }
    
    public String getCustomStyle(){
        return this.customStyle;
    }
    public double getCustomStyleCost(){
        return this.customStyleCost;
    }
    public void updateCustomStyleCost(double customStyleCost){
        this.customStyleCost = customStyleCost;
    }
    @Override
    public double getTotalCost(){
        return this.getCost() + customStyleCost ;
    }
    
    @Override
    public String toString(){
        return "Grooming Service with "+ this.getGroomer().getName();
    }
}
