/*
 * Description: this is the DogGroomingAppGUI class.
 * this is a Graphical User Interface for Dog Grooming App Activities
 * the class allows the creation and viewing of Clients, Groomers, Dogs and Services 
 * it also alows booking to be made by clients
 * 
 * Created Date: 2021-07-09
 */
package rgu;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class DogGroomingAppGUI extends javax.swing.JFrame {

    /**
     * Creates new form DogGroomingAppGUI
     */
    private ArrayList<Groomer> groomers; //arraylist for groomers
    private ArrayList<Booking> bookings; //arraylist for bookins
    private ArrayList<Service> services; //arraylist for services
    private ArrayList<Client> clients; //arraylist for clients
    private ArrayList<Dog> dogs;// Arralist for dogs

    public DogGroomingAppGUI() {

        initComponents();
        try {
            //initializing Dog Grooming App
            //creating two groomers and adding them to an array List
            this.groomers = new ArrayList<Groomer>() {
                {
                    add(new Groomer("Andy", "Cleaning Dog"));
                    add(new Groomer("Jack", "Training Dog"));
                }
            };

            //creating four services and adding them to the array list
            GroomingService service1 = new GroomingService("Neaten", 200, "Grooming Service", groomers.get(0), 350);
            GroomingService service2 = new GroomingService("The Lion Cut", 250, "Groomin service", groomers.get(1), 350);
            TrainingService service3 = new TrainingService(2, 150, "Training Service", groomers.get(1), 100);
            CleaningService service4 = new CleaningService(true, false, 100, 80, "Cleaning Service", groomers.get(0), 200);
            //Creating and Initializing to array list services
            this.services = new ArrayList<Service>() {
                {
                    add(service1);
                    add(service2);
                    add(service3);
                    add(service4);
                }
            };

            //initializing dog Array list
            this.dogs = new ArrayList<Dog>() {
                {
                    add(new Dog("Fluffy", 3, DogBreed.POODLE));
                }
            };
            //Creating one Client and adding him to the array list
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Client client1 = new Client("Mr. Pius", sdf.parse("20/12/2020"), dogs.get(0));
            this.clients = new ArrayList<Client>() {
                {
                    add(client1);
                }
            };
            //create and initialize bookin object
            sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm a");
            Booking booking1 = new Booking(clients.get(0), services.get(0), sdf.parse("10-07-2021 10:30 am"));
            Booking booking2 = new Booking(clients.get(0), services.get(3), sdf.parse("10-07-2021 12:0 pm"));
            //create and initilize ArrayList Booking
            bookings = new ArrayList<Booking>() {
                {
                    add(booking1);
                    add(booking2);
                }
            };
        } catch (ParseException ex) {
            Logger.getLogger(DogGroomingAppGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        //call the reload Groomers() method to initialize groomer 
        reloadGroomers();
    }

    private void reloadGroomers() {

        /* The reloadGroomers method is designed to refresh the the groomers form model*/
        //clear the nameTextField and specialityTextField
        groomerNameTextField.setText("");
        groomerSpecialityTextField.setText("");
        groomerSaveButton.setText("Save");
        deleteGroomerButton.setVisible(false);
        //adding to DefaultListModel
        DefaultListModel dml = new DefaultListModel();
        try {
            groomers.forEach(g -> {
                dml.addElement(g.getName());
            });
            groomerList.setModel(dml);
        } catch (Exception e) {
        }
    }

    private void reloadClients() {

        clientNameTextField.setText("");

        clientJoinedTextField.setText("");

        clientDogNameTextField.setText("");

        clientDogAgeTextField.setText("");

        clientSaveButton.setText("Save");

        dogUpdateAge.setVisible(false);

        //reload Client List
        DefaultComboBoxModel dml = new DefaultComboBoxModel();

        for (Client c : clients) {

            dml.addElement(c.getName());

        }

        clientCombo.setModel(dml);

        //reload Dog 
        dml = new DefaultComboBoxModel();

        for (Dog d : dogs) {

            dml.addElement(d.getName());

        };

        clientDogCombo.setModel(dml);

        //load Dog Breeds
        dml = new DefaultComboBoxModel<>(DogBreed.values());

        dogBreedCombo.setModel(dml);

    }

    private void reloadServices() {
        //HOUSE KEEPING
        servicesDescriptionTextField.setText("");
        serviceCostTextField.setText("");
        nailsCostTextField.setText("");
        teethCostTextField.setText("");
        customStyleTextField.setText("");
        serviceCostTextField.setText("");
        sessionsTextField.setText("");
        sessionPriceTextField.setText("");
        //clear the service type selection
        servicesType.clearSelection();
        cleaningPanel.setVisible(false);
        groomingPanel.setVisible(false);
        trainingPanel.setVisible(false);
        //reload service combo model
        DefaultComboBoxModel dml = new DefaultComboBoxModel();
        for (Service s : services) {
            dml.addElement(s.toString());
        }
        servicesCombo.setModel(dml);
        //reload groomer combo model
        dml = new DefaultComboBoxModel();
        for (Groomer g : groomers) {
            dml.addElement(g.getName());
        }
        servicesGroomerCombo.setModel(dml);
    }

private void reloadBookings() {
        //reload bookings
        DefaultComboBoxModel dml = new DefaultComboBoxModel();
        for (Booking d : bookings) {
            dml.addElement(d.toString());
        }
        bookingCombo.setModel(dml);
        //reload services
        dml = new DefaultComboBoxModel();
        for (Service d : services) {
            dml.addElement(d.toString());
        }

        bookingServicesCombo.setModel(dml);
        //reload services
        dml = new DefaultComboBoxModel();
        for (Client d : clients) {
            dml.addElement(d.getName());
        }
        bookingClientsCombo.setModel(dml);
        bookingDateTextField.setText("");
        bookingSaveButton.setText("Save");
        cancelBookingButton.setVisible(false);

    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        servicesType = new javax.swing.ButtonGroup();
        myTab = new javax.swing.JTabbedPane();
        groomersPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        groomerList = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        groomerNameTextField = new javax.swing.JTextField();
        groomerSpecialityTextField = new javax.swing.JTextField();
        groomerSaveButton = new javax.swing.JButton();
        clearGroomerButton = new javax.swing.JButton();
        deleteGroomerButton = new javax.swing.JButton();
        clientsPanel = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        clientCombo = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        clientDogCombo = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        clientDogNameTextField = new javax.swing.JTextField();
        clientDogAgeTextField = new javax.swing.JTextField();
        dogBreedCombo = new javax.swing.JComboBox<>();
        saveDogButton = new javax.swing.JButton();
        dogUpdateAge = new javax.swing.JButton();
        clientNameTextField = new javax.swing.JTextField();
        clientJoinedTextField = new javax.swing.JTextField();
        clientSaveButton = new javax.swing.JButton();
        clientClearButton = new javax.swing.JButton();
        clientViewBill = new javax.swing.JButton();
        servicesPanel = new javax.swing.JPanel();
        cleaningPanel = new javax.swing.JPanel();
        teethCheckBox = new javax.swing.JCheckBox();
        jLabel15 = new javax.swing.JLabel();
        teethCostTextField = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        nailsCostTextField = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        nailsCheckBox = new javax.swing.JCheckBox();
        jLabel10 = new javax.swing.JLabel();
        servicesCombo = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        servicesGroomerCombo = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        servicesDescriptionTextField = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        cleaningRadioButton = new javax.swing.JRadioButton();
        groomingRadioButton = new javax.swing.JRadioButton();
        trainingRadioButton = new javax.swing.JRadioButton();
        jLabel14 = new javax.swing.JLabel();
        serviceCostTextField = new javax.swing.JTextField();
        groomingPanel = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        customStyleTextField = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        customStylePriceTextField = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        trainingPanel = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        sessionPriceTextField = new javax.swing.JTextField();
        sessionsTextField = new javax.swing.JTextField();
        servicesSaveButton = new javax.swing.JButton();
        servicesClearButton = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        bookingSaveButton = new javax.swing.JButton();
        cancelBookingButton = new javax.swing.JButton();
        bookingClearButton = new javax.swing.JButton();
        bookingClientsCombo = new javax.swing.JComboBox<>();
        bookingCombo = new javax.swing.JComboBox<>();
        bookingServicesCombo = new javax.swing.JComboBox<>();
        bookingDateTextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Dog Grooming App");

        myTab.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                myTabStateChanged(evt);
            }
        });

        jScrollPane1.setToolTipText("Groomer's List");

        groomerList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                groomerListValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(groomerList);

        jLabel1.setText("Name :");

        jLabel2.setText("Speciality :");

        groomerSaveButton.setText("Save");
        groomerSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                groomerSaveButtonActionPerformed(evt);
            }
        });

        clearGroomerButton.setText("Clear");
        clearGroomerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearGroomerButtonActionPerformed(evt);
            }
        });

        deleteGroomerButton.setText("Delete");
        deleteGroomerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteGroomerButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout groomersPanelLayout = new javax.swing.GroupLayout(groomersPanel);
        groomersPanel.setLayout(groomersPanelLayout);
        groomersPanelLayout.setHorizontalGroup(
            groomersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(groomersPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(groomersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(groomersPanelLayout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addGroup(groomersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(21, 21, 21)
                        .addGroup(groomersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(groomerNameTextField)
                            .addComponent(groomerSpecialityTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 326, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(groomersPanelLayout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addComponent(clearGroomerButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                        .addComponent(deleteGroomerButton)
                        .addGap(46, 46, 46)
                        .addComponent(groomerSaveButton)
                        .addContainerGap())))
        );
        groomersPanelLayout.setVerticalGroup(
            groomersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(groomersPanelLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(groomersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(groomerNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(78, 78, 78)
                .addGroup(groomersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(groomerSpecialityTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 428, Short.MAX_VALUE)
                .addGroup(groomersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(groomerSaveButton)
                    .addComponent(clearGroomerButton)
                    .addComponent(deleteGroomerButton))
                .addContainerGap())
        );

        myTab.addTab("Groomers", groomersPanel);

        jLabel3.setText("Clients :");

        clientCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clientComboActionPerformed(evt);
            }
        });

        jLabel4.setText("Name :");

        jLabel5.setText("Date Joined :");

        jLabel6.setText("Dog :");

        clientDogCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clientDogComboActionPerformed(evt);
            }
        });

        jLabel7.setText("Name :");

        jLabel8.setText("Age :");

        jLabel9.setText("Breed :");

        clientDogNameTextField.setToolTipText("Dog's Name");

        clientDogAgeTextField.setToolTipText("Dog's Age");

        dogBreedCombo.setToolTipText("Dog's Breed");

        saveDogButton.setText("Save");
        saveDogButton.setToolTipText("Save Dog Details");
        saveDogButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveDogButtonActionPerformed(evt);
            }
        });

        dogUpdateAge.setText("Update Age");
        dogUpdateAge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dogUpdateAgeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(26, 26, 26)
                        .addComponent(clientDogCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(18, 18, 18)
                                .addComponent(dogBreedCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(clientDogNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(clientDogAgeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(28, 28, 28))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(dogUpdateAge)
                .addGap(28, 28, 28)
                .addComponent(saveDogButton)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(clientDogCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(clientDogNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clientDogAgeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(dogBreedCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(saveDogButton)
                    .addComponent(dogUpdateAge))
                .addContainerGap())
        );

        clientNameTextField.setToolTipText("Client's Name");

        clientJoinedTextField.setToolTipText("DD/MM/YYYY");

        clientSaveButton.setText("Save");
        clientSaveButton.setToolTipText("Save Client's Details");
        clientSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clientSaveButtonActionPerformed(evt);
            }
        });

        clientClearButton.setText("Clear");
        clientClearButton.setToolTipText("Clear Client's Details");
        clientClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clientClearButtonActionPerformed(evt);
            }
        });

        clientViewBill.setText("View Client's Bill");
        clientViewBill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clientViewBillActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout clientsPanelLayout = new javax.swing.GroupLayout(clientsPanel);
        clientsPanel.setLayout(clientsPanelLayout);
        clientsPanelLayout.setHorizontalGroup(
            clientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(clientsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(clientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(clientsPanelLayout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(clientNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(clientJoinedTextField))
                    .addGroup(clientsPanelLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addGroup(clientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(clientCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(86, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, clientsPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientClearButton)
                .addGap(49, 49, 49)
                .addComponent(clientViewBill)
                .addGap(63, 63, 63)
                .addComponent(clientSaveButton)
                .addGap(30, 30, 30))
        );
        clientsPanelLayout.setVerticalGroup(
            clientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(clientsPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(clientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(clientCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addGroup(clientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(clientNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clientJoinedTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 186, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72)
                .addGroup(clientsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clientSaveButton)
                    .addComponent(clientClearButton)
                    .addComponent(clientViewBill))
                .addContainerGap())
        );

        myTab.addTab("Clients", clientsPanel);

        servicesPanel.setLayout(null);

        cleaningPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        teethCheckBox.setText("Include Teeth Brushing?");

        jLabel15.setText("Cost For Teeth Brushing");

        jLabel16.setText("£");

        jLabel17.setText("£");

        jLabel18.setText("Cost For Nails Trimming");

        nailsCheckBox.setText("Include Nails Trimming?");

        javax.swing.GroupLayout cleaningPanelLayout = new javax.swing.GroupLayout(cleaningPanel);
        cleaningPanel.setLayout(cleaningPanelLayout);
        cleaningPanelLayout.setHorizontalGroup(
            cleaningPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cleaningPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cleaningPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cleaningPanelLayout.createSequentialGroup()
                        .addComponent(teethCheckBox)
                        .addGap(58, 58, 58)
                        .addComponent(jLabel15)
                        .addGap(43, 43, 43)
                        .addComponent(teethCostTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel16))
                    .addGroup(cleaningPanelLayout.createSequentialGroup()
                        .addComponent(nailsCheckBox)
                        .addGap(58, 58, 58)
                        .addComponent(jLabel18)
                        .addGap(43, 43, 43)
                        .addComponent(nailsCostTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17)))
                .addContainerGap(169, Short.MAX_VALUE))
        );
        cleaningPanelLayout.setVerticalGroup(
            cleaningPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cleaningPanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(cleaningPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(teethCheckBox)
                    .addComponent(jLabel15)
                    .addComponent(teethCostTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(cleaningPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nailsCheckBox)
                    .addComponent(jLabel18)
                    .addComponent(nailsCostTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17))
                .addGap(37, 37, 37))
        );

        servicesPanel.add(cleaningPanel);
        cleaningPanel.setBounds(50, 360, 627, 150);

        jLabel10.setText("Services :");
        servicesPanel.add(jLabel10);
        jLabel10.setBounds(20, 20, 80, 30);

        servicesCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                servicesComboActionPerformed(evt);
            }
        });
        servicesPanel.add(servicesCombo);
        servicesCombo.setBounds(140, 20, 570, 30);

        jLabel11.setText("Groomers: ");
        servicesPanel.add(jLabel11);
        jLabel11.setBounds(20, 70, 80, 30);

        servicesPanel.add(servicesGroomerCombo);
        servicesGroomerCombo.setBounds(140, 70, 570, 30);

        jLabel12.setText("Description: ");
        servicesPanel.add(jLabel12);
        jLabel12.setBounds(20, 120, 80, 30);
        servicesPanel.add(servicesDescriptionTextField);
        servicesDescriptionTextField.setBounds(140, 120, 570, 30);

        jLabel13.setText("Type : ");
        servicesPanel.add(jLabel13);
        jLabel13.setBounds(20, 310, 50, 20);

        servicesType.add(cleaningRadioButton);
        cleaningRadioButton.setText("Cleaning");
        cleaningRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cleaningRadioButtonActionPerformed(evt);
            }
        });
        servicesPanel.add(cleaningRadioButton);
        cleaningRadioButton.setBounds(100, 300, 100, 40);

        servicesType.add(groomingRadioButton);
        groomingRadioButton.setText("Grooming");
        groomingRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                groomingRadioButtonActionPerformed(evt);
            }
        });
        servicesPanel.add(groomingRadioButton);
        groomingRadioButton.setBounds(310, 300, 90, 40);

        servicesType.add(trainingRadioButton);
        trainingRadioButton.setText("Training");
        trainingRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trainingRadioButtonActionPerformed(evt);
            }
        });
        servicesPanel.add(trainingRadioButton);
        trainingRadioButton.setBounds(560, 310, 90, 30);

        jLabel14.setText("Service Cost :");
        servicesPanel.add(jLabel14);
        jLabel14.setBounds(20, 170, 90, 30);
        servicesPanel.add(serviceCostTextField);
        serviceCostTextField.setBounds(140, 170, 170, 30);

        groomingPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel19.setText("Custom Style:");

        jLabel20.setText("Custom Style Cost");

        jLabel21.setText("£");

        javax.swing.GroupLayout groomingPanelLayout = new javax.swing.GroupLayout(groomingPanel);
        groomingPanel.setLayout(groomingPanelLayout);
        groomingPanelLayout.setHorizontalGroup(
            groomingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(groomingPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(groomingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(groomingPanelLayout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addGap(39, 39, 39)
                        .addComponent(customStyleTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(groomingPanelLayout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addGap(18, 18, 18)
                        .addComponent(customStylePriceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel21)))
                .addContainerGap(219, Short.MAX_VALUE))
        );
        groomingPanelLayout.setVerticalGroup(
            groomingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(groomingPanelLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(groomingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(customStyleTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(groomingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(customStylePriceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21))
                .addGap(28, 28, 28))
        );

        servicesPanel.add(groomingPanel);
        groomingPanel.setBounds(50, 360, 630, 150);

        trainingPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel22.setText("No. of Sessions :");

        jLabel23.setText("Cost per Session :");

        javax.swing.GroupLayout trainingPanelLayout = new javax.swing.GroupLayout(trainingPanel);
        trainingPanel.setLayout(trainingPanelLayout);
        trainingPanelLayout.setHorizontalGroup(
            trainingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(trainingPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(trainingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addComponent(jLabel22))
                .addGap(18, 18, 18)
                .addGroup(trainingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(sessionPriceTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                    .addComponent(sessionsTextField))
                .addContainerGap(390, Short.MAX_VALUE))
        );
        trainingPanelLayout.setVerticalGroup(
            trainingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(trainingPanelLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(trainingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(sessionsTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(trainingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(sessionPriceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        servicesPanel.add(trainingPanel);
        trainingPanel.setBounds(50, 360, 630, 150);

        servicesSaveButton.setText("Save");
        servicesSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                servicesSaveButtonActionPerformed(evt);
            }
        });
        servicesPanel.add(servicesSaveButton);
        servicesSaveButton.setBounds(597, 573, 80, 30);

        servicesClearButton.setText("Clear");
        servicesClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                servicesClearButtonActionPerformed(evt);
            }
        });
        servicesPanel.add(servicesClearButton);
        servicesClearButton.setBounds(420, 573, 80, 30);

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel24.setText("£");
        servicesPanel.add(jLabel24);
        jLabel24.setBounds(320, 170, 30, 30);

        myTab.addTab("Services", servicesPanel);

        jLabel25.setText("Bookings :");

        jLabel26.setText("Client's Name : ");

        jLabel27.setText("Services : ");

        jLabel28.setText("Date/Time : ");

        bookingSaveButton.setText("Save");
        bookingSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookingSaveButtonActionPerformed(evt);
            }
        });

        cancelBookingButton.setText("Cancel Booking");
        cancelBookingButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelBookingButtonActionPerformed(evt);
            }
        });

        bookingClearButton.setText("Clear");
        bookingClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookingClearButtonActionPerformed(evt);
            }
        });

        bookingCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookingComboActionPerformed(evt);
            }
        });

        bookingDateTextField.setToolTipText("DD/MM/YYYY HH:MM AM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel26)
                    .addComponent(jLabel25)
                    .addComponent(jLabel27)
                    .addComponent(jLabel28))
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(bookingClientsCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bookingCombo, 0, 592, Short.MAX_VALUE)
                        .addComponent(bookingServicesCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(bookingDateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(373, Short.MAX_VALUE)
                .addComponent(bookingClearButton)
                .addGap(77, 77, 77)
                .addComponent(cancelBookingButton)
                .addGap(71, 71, 71)
                .addComponent(bookingSaveButton)
                .addGap(19, 19, 19))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(bookingCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(49, 49, 49)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(bookingClientsCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(53, 53, 53)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel27)
                            .addComponent(bookingServicesCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(56, 56, 56)
                        .addComponent(jLabel28))
                    .addComponent(bookingDateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(86, 86, 86)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bookingSaveButton)
                    .addComponent(cancelBookingButton)
                    .addComponent(bookingClearButton))
                .addContainerGap(263, Short.MAX_VALUE))
        );

        myTab.addTab("Bookings", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(myTab, javax.swing.GroupLayout.PREFERRED_SIZE, 764, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(myTab, javax.swing.GroupLayout.PREFERRED_SIZE, 643, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deleteGroomerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteGroomerButtonActionPerformed
        // this code is intended to delete the selected Groomer

        //get the selected index
        if (groomerList.getSelectedIndex() >= 0) {
            int g = groomerList.getSelectedIndex();
        }
    }//GEN-LAST:event_deleteGroomerButtonActionPerformed

    private void groomerSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_groomerSaveButtonActionPerformed
        // this code is inteneded to Save new Groomers Details

        //checking if any field is empty
        String name = groomerNameTextField.getText();
        //checking if the agent name field is empty
        if ("".equals(name)) {
            JOptionPane.showMessageDialog(null, "Please Enter the Groomer\'s Name", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
            groomerNameTextField.requestFocus();
            return;
        }
        //accepting the value at location field
        String speciality = groomerSpecialityTextField.getText();
        //checking if the location field is empty
        if ("".equals(speciality)) {
            JOptionPane.showMessageDialog(null, "Please Enter the Speciality of the Groomer", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
            groomerSpecialityTextField.requestFocus();
            return;
        }
        DefaultListModel dml = new DefaultListModel();
        //check if the button Text is save or Update
        if ("Update".equals(groomerSaveButton.getText())) {
            int groomerIndex = groomerList.getSelectedIndex();
            //get the updated groomer
            Groomer g = groomers.get(groomerIndex);
            g.setName(name);
            g.setDescription(speciality);
            //update the groomer in the arrayList
            groomers.set(groomerIndex, g);
            //reloading DefaultListModel
            reloadGroomers();
            //groomerList = new JList(dml);
            JOptionPane.showMessageDialog(null, "Groomer Updated Successfully", "Dog Grooming App", JOptionPane.INFORMATION_MESSAGE);
        } else {
            groomers.add(new Groomer(name, speciality));
            //reloading DefaultListModel
            reloadGroomers();
            JOptionPane.showMessageDialog(null, "Groomer Added Successfully", "Dog Grooming App", JOptionPane.INFORMATION_MESSAGE);

        }
        groomerList.clearSelection();

    }//GEN-LAST:event_groomerSaveButtonActionPerformed

    private void clearGroomerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearGroomerButtonActionPerformed
        // this code is intended to refresh the groomers model

        //call the reload method
        reloadGroomers();
        //set focus to nameTextField
        groomerNameTextField.requestFocus();
    }//GEN-LAST:event_clearGroomerButtonActionPerformed

    private void groomerListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_groomerListValueChanged
        // this code is intended to load the details of the selected groomer

        //set the value of the selected groomer to the nameTextField and 
        //the SpecialtyTextField
        if (groomerList.getSelectedIndex() >= 0) {
            Groomer g = groomers.get(groomerList.getSelectedIndex());
            groomerNameTextField.setText(g.getName());
            groomerSpecialityTextField.setText(g.getDescription());
            groomerSaveButton.setText("Update");
            deleteGroomerButton.setVisible(true);
        }
    }//GEN-LAST:event_groomerListValueChanged

    private void myTabStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_myTabStateChanged
        //JTabbedPane p = (JTabbedPane)e.getSource();
        int idx = myTab.getSelectedIndex();
        switch (idx) {
            case 0:
                reloadGroomers();
                break;
            case 1:
                reloadClients();
                break;
            case 2:
                reloadServices();
                break;
            case 3:
                reloadBookings();
                break;
            default:
                break;
        }
    }//GEN-LAST:event_myTabStateChanged

    private void clientSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clientSaveButtonActionPerformed
        // this code is intended to save/update Cleint's details 
        //validate inputs
        String name = clientNameTextField.getText();
        //checking if the agent name field is empty
        if ("".equals(name)) {
            JOptionPane.showMessageDialog(null, "Please Enter the Client\'s Name", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
            groomerNameTextField.requestFocus();
            return;
        }
        if ("Save".equals(clientSaveButton.getText())) {
            String joined = clientJoinedTextField.getText();
            //checking if the agent name field is empty
            if ("".equals(joined)) {
                JOptionPane.showMessageDialog(null, "Please Enter the Client\'s Joined Date", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                groomerNameTextField.requestFocus();
                return;
            }
            SimpleDateFormat ft = new SimpleDateFormat("dd/MM/yyyy");
            Date date = new Date();
            try {
                date = ft.parse(joined);
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Please Enter Date and Time in \"DD/MM/YYYY\" format", "Dog Grooming App ", JOptionPane.ERROR_MESSAGE);
                clientJoinedTextField.requestFocus();
                return;

            }
            clients.add(new Client(name, date, dogs.get(clientDogCombo.getSelectedIndex())));
            JOptionPane.showMessageDialog(null, "Client\'s Details Have been Added Successfully", "Dog Grooming App", JOptionPane.INFORMATION_MESSAGE);
        } else {
            clients.get(clientCombo.getSelectedIndex()).updateName(name);
            JOptionPane.showMessageDialog(null, "Client\'s Name Have been Updated Successfully", "Dog Grooming App", JOptionPane.INFORMATION_MESSAGE);
        }
        reloadClients();
    }//GEN-LAST:event_clientSaveButtonActionPerformed

    private void clientClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clientClearButtonActionPerformed
        // This code is intended to clear the clients information in other to ad  new client
        reloadClients();
        clientNameTextField.requestFocus();
    }//GEN-LAST:event_clientClearButtonActionPerformed

    private void clientComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clientComboActionPerformed
        // This code is intended to load the selected client details
        // getting the selected index.
        int selected = clientCombo.getSelectedIndex();

        //get the selected client from the clients arrayList
        Client c = clients.get(selected);
        clientNameTextField.setText(c.getName());
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        clientJoinedTextField.setText(sdf.format(c.getJoined()));
        Dog d = c.getDog();
        clientDogCombo.setSelectedItem(d.getName());
        clientDogNameTextField.setText(d.getName());
        clientDogAgeTextField.setText(Integer.toString(d.getAge()));
        dogBreedCombo.setSelectedItem(d.getBreed());
        clientSaveButton.setText("Update");
    }//GEN-LAST:event_clientComboActionPerformed

    private void clientDogComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clientDogComboActionPerformed
        // this code is inteneded to load the selected dog information
        //load dogs information
        int dogIndex = clientDogCombo.getSelectedIndex();

        clientDogNameTextField.setText(dogs.get(dogIndex).getName());
        clientDogAgeTextField.setText(Integer.toString(dogs.get(dogIndex).getAge()));
        dogBreedCombo.setSelectedItem(dogs.get(dogIndex).getBreed());
        dogUpdateAge.setVisible(true);

    }//GEN-LAST:event_clientDogComboActionPerformed

    private void dogUpdateAgeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dogUpdateAgeActionPerformed
        // This Code is intended to update the age of the selected Dog
        //get the selected index
        int dogIndex = clientDogCombo.getSelectedIndex();
        int dogAge;
        //try parsing the age of the dog
        try {
            if (!"".equals(clientDogAgeTextField.getText())) {
                dogAge = Integer.parseInt(clientDogAgeTextField.getText());
            } else {
                JOptionPane.showMessageDialog(null, "Please Enter valid Dog\'s Age in numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                clientDogAgeTextField.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please Enter valid Dog\'s Age in numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
            clientDogAgeTextField.requestFocus();
            return;

        }
        dogs.get(dogIndex).updateAge(dogAge);
        reloadClients();
        JOptionPane.showMessageDialog(this, "Dog age Update Successfully", "Dog Gromming App", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_dogUpdateAgeActionPerformed

    private void saveDogButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveDogButtonActionPerformed
        //This Code is intended to save new dog Details
        //checking if the agent name field is empty
        String dogName = clientDogNameTextField.getText();
        if ("".equals(dogName)) {
            JOptionPane.showMessageDialog(null, "Please Enter the Client Dog\'s Name", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
            clientDogNameTextField.requestFocus();
            return;
        }
        int dogAge;
        try {
            if (!"".equals(clientDogAgeTextField.getText())) {
                dogAge = Integer.parseInt(clientDogAgeTextField.getText());
            } else {
                JOptionPane.showMessageDialog(null, "Please Enter valid Dog\'s Age in numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                clientDogAgeTextField.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please Enter valid Dog\'s Age in numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
            clientDogAgeTextField.requestFocus();
            return;
        }
        //create new Dog object and add it to the arraylist
        dogs.add(new Dog(dogName, dogAge, (DogBreed) dogBreedCombo.getSelectedItem()));

        //refresh the form
        reloadClients();
        JOptionPane.showMessageDialog(this, "Dog Added Successfully", "Dog Gromming App", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_saveDogButtonActionPerformed

    private void servicesComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_servicesComboActionPerformed
        // this code is intended to load the selected services
        // Load Services
        int serviceIndex = servicesCombo.getSelectedIndex();

        Service service = services.get(serviceIndex);
        servicesDescriptionTextField.setText(service.getDescription());
        servicesGroomerCombo.setSelectedItem(service.getGroomer().getName());
        serviceCostTextField.setText(Double.toString(service.getCost()));
        //check which services is beeing used
        String s = service.getClass().getSimpleName();
        if ("CleaningService".equals(s)) {
            nailsCheckBox.setSelected(((CleaningService) service).includeTrimNails());
            teethCheckBox.setSelected(((CleaningService) service).includeBrushTeeth());
            nailsCostTextField.setText(Double.toString(((CleaningService) service).getNailTrimCost()));
            teethCostTextField.setText(Double.toString(((CleaningService) service).getBrushTeethCost()));
            cleaningRadioButton.doClick();
        } else if ("GroomingService".equals(s)) {
            customStyleTextField.setText(((GroomingService) service).getCustomStyle());
            customStylePriceTextField.setText(Double.toString(((GroomingService) service).getCustomStyleCost()));
            groomingRadioButton.doClick();
        } else if ("TrainingService".equals(s)) {
            sessionsTextField.setText(Integer.toString(((TrainingService) service).getSessions()));
            sessionPriceTextField.setText(Double.toString(((TrainingService) service).getSessionCost()));
            trainingRadioButton.doClick();
        }
        servicesSaveButton.setText("Update");

    }//GEN-LAST:event_servicesComboActionPerformed

    private void cleaningRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cleaningRadioButtonActionPerformed
        // this code is intended to display the cleaning panel
        // set the cleaningpanel.visible.
        cleaningPanel.setVisible(true);
        groomingPanel.setVisible(false);
        trainingPanel.setVisible(false);

    }//GEN-LAST:event_cleaningRadioButtonActionPerformed

    private void groomingRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_groomingRadioButtonActionPerformed
        // this code is intended to display the grooming Panel
        // set the groomingpanel.visible.
        cleaningPanel.setVisible(false);
        groomingPanel.setVisible(true);
        trainingPanel.setVisible(false);
    }//GEN-LAST:event_groomingRadioButtonActionPerformed

    private void trainingRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trainingRadioButtonActionPerformed
        // this code is intended to display the training Panel
        // set the trainingpanel.visible.
        cleaningPanel.setVisible(false);
        groomingPanel.setVisible(false);
        trainingPanel.setVisible(true);
    }//GEN-LAST:event_trainingRadioButtonActionPerformed

    private void servicesClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_servicesClearButtonActionPerformed
        // this code is intended to reset the services Panel
        reloadServices();
    }//GEN-LAST:event_servicesClearButtonActionPerformed

    private void servicesSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_servicesSaveButtonActionPerformed
        // this Code is intended to save new added Services
        //check actions
        //get values
        String desc = servicesDescriptionTextField.getText();
        double serviceCost = Double.parseDouble(serviceCostTextField.getText());
        Groomer groomer = groomers.get(servicesGroomerCombo.getSelectedIndex());
        boolean withNails, withBrush;
        double nailsCost, teethCost, sessionPrice, stylePrice;
        String customStyle;

        int sessions;
        if (servicesSaveButton.getText() == "Save") {

            Service service;
            //check which service is selected
            if (cleaningRadioButton.isSelected()) {
                withNails = nailsCheckBox.isSelected();
                withBrush = teethCheckBox.isSelected();

                if (nailsCostTextField.getText() != "") {
                    nailsCost = Double.parseDouble(nailsCostTextField.getText());

                } else {
                    JOptionPane.showMessageDialog(null, "number of nails trimming price must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (teethCostTextField.getText() != "") {
                    teethCost = Double.parseDouble(teethCostTextField.getText());

                } else {
                    JOptionPane.showMessageDialog(null, "number of teeth brushing price must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                //create new cleaning service object
                service = new CleaningService(withBrush, withNails, nailsCost, teethCost, desc, groomer, serviceCost);

            } else if (trainingRadioButton.isSelected()) {
                if (sessionsTextField.getText() != "") {
                    sessions = Integer.parseInt(sessionsTextField.getText());
                    if (sessions < 1) {
                        JOptionPane.showMessageDialog(null, "number of sessions must be greater than 0", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "number of sessions must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (sessionPriceTextField.getText() != "") {
                    sessionPrice = Double.parseDouble(sessionPriceTextField.getText());
                    if (sessionPrice <= 0.0) {
                        JOptionPane.showMessageDialog(null, "Please set session Price", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "number of sessions price must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                //code for creating new training object
                service = new TrainingService(sessions, sessionPrice, desc, groomer, serviceCost);
            } else if (groomingRadioButton.isSelected()) {
                customStyle = customStyleTextField.getText();

                if (customStylePriceTextField.getText() != "") {
                    stylePrice = Double.parseDouble(customStylePriceTextField.getText());

                } else {
                    JOptionPane.showMessageDialog(null, "number of custom price must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                //create new grooming services object
                service = new GroomingService(customStyle, stylePrice, desc, groomer, serviceCost);
            } else {
                JOptionPane.showMessageDialog(null, "Please Service Type", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                return;
            }

            services.add(service);
            reloadServices();

            JOptionPane.showMessageDialog(this, "New Service Added Successfully", "Dog Gromming App", JOptionPane.INFORMATION_MESSAGE);
        } else {
            int serviceIndex = servicesCombo.getSelectedIndex();
            ///update services costs
            if (cleaningRadioButton.isSelected()) {
                if (nailsCostTextField.getText() != "") {
                    nailsCost = Double.parseDouble(nailsCostTextField.getText());

                } else {
                    JOptionPane.showMessageDialog(null, "number of nails trimming price must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (teethCostTextField.getText() != "") {
                    teethCost = Double.parseDouble(teethCostTextField.getText());

                } else {
                    JOptionPane.showMessageDialog(null, "number of teeth brushing price must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                //create new cleaning service object
                services.get(serviceIndex).updateCost(serviceCost);
                ((CleaningService) services.get(serviceIndex)).updateBrushTeethCost(teethCost);
                ((CleaningService) services.get(serviceIndex)).updateNailTrimCost(teethCost);

            } else if (trainingRadioButton.isSelected()) {
                if (sessionsTextField.getText() != "") {
                    sessions = Integer.parseInt(sessionsTextField.getText());
                    if (sessions < 1) {
                        JOptionPane.showMessageDialog(null, "number of sessions must be greater than 0", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "number of sessions must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (sessionPriceTextField.getText() != "") {
                    sessionPrice = Double.parseDouble(sessionPriceTextField.getText());
                    if (sessionPrice <= 0.0) {
                        JOptionPane.showMessageDialog(null, "Please set session Price", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "number of sessions price must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                //code for update values of training object
                services.get(serviceIndex).updateCost(serviceCost);
                ((TrainingService) services.get(serviceIndex)).updateSessions(sessions);
                ((TrainingService) services.get(serviceIndex)).updateSessionCost(sessionPrice);

            } else if (groomingRadioButton.isSelected()) {

                if (customStylePriceTextField.getText() != "") {
                    stylePrice = Double.parseDouble(customStylePriceTextField.getText());
                    //update values
                    services.get(serviceIndex).updateCost(serviceCost);
                    ((GroomingService) services.get(serviceIndex)).updateCustomStyleCost(stylePrice);

                } else {
                    JOptionPane.showMessageDialog(null, "number of custom price must be numeric", "Dog Grooming App", JOptionPane.ERROR_MESSAGE);
                    return;
                }

            }
            //reload services
            reloadServices();

            JOptionPane.showMessageDialog(this, "Service Updated Successfully", "Dog Gromming App", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_servicesSaveButtonActionPerformed

    private void bookingComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookingComboActionPerformed
        // TODO add your handling code here:
        
         int bookingIndex = bookingCombo.getSelectedIndex();
        bookingClientsCombo.setSelectedItem(bookings.get(bookingIndex).getClient().getName());
        bookingServicesCombo.setSelectedItem(bookings.get(bookingIndex).getService().toString());
        SimpleDateFormat ft = new SimpleDateFormat("dd/MM/yyyy HH:mm a");
        bookingDateTextField.setText(ft.format(bookings.get(bookingIndex).getDatetime()));
        bookingSaveButton.setText("Update");
        cancelBookingButton.setVisible(true);
    }//GEN-LAST:event_bookingComboActionPerformed

    private void bookingClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookingClearButtonActionPerformed
        // TODO add your handling code here:
        
        //refresh entry
        reloadBookings();
        bookingClientsCombo.requestFocus();
    }//GEN-LAST:event_bookingClearButtonActionPerformed

    private void bookingSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookingSaveButtonActionPerformed
        // this code is intended to save new booking
        
        //get selected index of client
        int clientIndex = bookingClientsCombo.getSelectedIndex();
        int servicesIndex = bookingServicesCombo.getSelectedIndex();
        SimpleDateFormat ft = new SimpleDateFormat("dd/MM/yyyy HH:mm a");
        Date date = new Date();
        try {

            date = ft.parse(bookingDateTextField.getText());
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Please Enter Date and Time in \"DD/MM/YYYY HH:MM AM\" format", "Dog Grooming App ", JOptionPane.ERROR_MESSAGE);
            clientJoinedTextField.requestFocus();

            return;

        }
        //add to Booking List
        String msg;
        if (bookingSaveButton.getText() == "Save") {
            bookings.add(new Booking(clients.get(clientIndex), services.get(servicesIndex), date));
            msg = "Added";
        } else {
            bookings.set(bookingCombo.getSelectedIndex(), new Booking(clients.get(clientIndex), services.get(servicesIndex), date));
            msg = "Updated";
        }
        //call reloadBookings
        reloadBookings();
        JOptionPane.showMessageDialog(this, "Booking " + msg + " Successfully", "Dog Gromming App", JOptionPane.INFORMATION_MESSAGE);



    }//GEN-LAST:event_bookingSaveButtonActionPerformed

    private void cancelBookingButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelBookingButtonActionPerformed
        // this code is intended to cancel the selected booking
        // get the index of the booking
        int bookingIndex = bookingCombo.getSelectedIndex();

        int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to Cancel this Booking? ", "Dog Gromming App", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
            bookings.remove(bookingIndex);
            //re-load the booking combo box
            reloadBookings();
            JOptionPane.showMessageDialog(this, "Booking deleted Successfully", "Dog Gromming App", JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_cancelBookingButtonActionPerformed

    private void clientViewBillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clientViewBillActionPerformed
        // this code is intended to calculate and display the total Bill of the Clients
        
        // Calculate Bills
        Client client = clients.get(clientCombo.getSelectedIndex());
        //creating an object of the bookingUtil class
        BookingUtil bu = new BookingUtil();
        double package2Cost[] = bu.calculateBill(bookings, client);
        //printing Tour Cost and discount for tourist 1
        String summary = client.getName() + "\'s total bill is " + package2Cost[0] + "£ and after discount it is " + package2Cost[1] + "£";
        JOptionPane.showMessageDialog(null, summary, "Tour App - Outstanding Bill ", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_clientViewBillActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DogGroomingAppGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DogGroomingAppGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DogGroomingAppGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DogGroomingAppGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DogGroomingAppGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bookingClearButton;
    private javax.swing.JComboBox<String> bookingClientsCombo;
    private javax.swing.JComboBox<String> bookingCombo;
    private javax.swing.JTextField bookingDateTextField;
    private javax.swing.JButton bookingSaveButton;
    private javax.swing.JComboBox<String> bookingServicesCombo;
    private javax.swing.JButton cancelBookingButton;
    private javax.swing.JPanel cleaningPanel;
    private javax.swing.JRadioButton cleaningRadioButton;
    private javax.swing.JButton clearGroomerButton;
    private javax.swing.JButton clientClearButton;
    private javax.swing.JComboBox<String> clientCombo;
    private javax.swing.JTextField clientDogAgeTextField;
    private javax.swing.JComboBox<String> clientDogCombo;
    private javax.swing.JTextField clientDogNameTextField;
    private javax.swing.JTextField clientJoinedTextField;
    private javax.swing.JTextField clientNameTextField;
    private javax.swing.JButton clientSaveButton;
    private javax.swing.JButton clientViewBill;
    private javax.swing.JPanel clientsPanel;
    private javax.swing.JTextField customStylePriceTextField;
    private javax.swing.JTextField customStyleTextField;
    private javax.swing.JButton deleteGroomerButton;
    private javax.swing.JComboBox<String> dogBreedCombo;
    private javax.swing.JButton dogUpdateAge;
    private javax.swing.JList<String> groomerList;
    private javax.swing.JTextField groomerNameTextField;
    private javax.swing.JButton groomerSaveButton;
    private javax.swing.JTextField groomerSpecialityTextField;
    private javax.swing.JPanel groomersPanel;
    private javax.swing.JPanel groomingPanel;
    private javax.swing.JRadioButton groomingRadioButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane myTab;
    private javax.swing.JCheckBox nailsCheckBox;
    private javax.swing.JTextField nailsCostTextField;
    private javax.swing.JButton saveDogButton;
    private javax.swing.JTextField serviceCostTextField;
    private javax.swing.JButton servicesClearButton;
    private javax.swing.JComboBox<String> servicesCombo;
    private javax.swing.JTextField servicesDescriptionTextField;
    private javax.swing.JComboBox<String> servicesGroomerCombo;
    private javax.swing.JPanel servicesPanel;
    private javax.swing.JButton servicesSaveButton;
    private javax.swing.ButtonGroup servicesType;
    private javax.swing.JTextField sessionPriceTextField;
    private javax.swing.JTextField sessionsTextField;
    private javax.swing.JCheckBox teethCheckBox;
    private javax.swing.JTextField teethCostTextField;
    private javax.swing.JPanel trainingPanel;
    private javax.swing.JRadioButton trainingRadioButton;
    // End of variables declaration//GEN-END:variables
}
