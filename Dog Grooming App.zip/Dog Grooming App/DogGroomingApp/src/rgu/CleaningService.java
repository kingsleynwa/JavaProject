/*
 * Description: this is the CleaningService.java class.
 * the class extends Service.java abstract class.
 * The CleaningService class  includes basic wash and dry service.
 * Created Date: 2021-07-01
 */
package rgu;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class CleaningService extends Service{
    //creating instance variable of the class
    private final boolean includeBrushTeeth;
    private final boolean includeTrimNails;
    private double nailTrimCost;
    private double brushTeethCost;
    
    //creating constructor method for the class
    public CleaningService(boolean includeBrushTeeth, boolean includeTrimNails, double nailTrimCost, double brushTeethCost, String description, Groomer groomer, double cost){
        super(description, groomer, cost);
        this.includeBrushTeeth = includeBrushTeeth;
        this.includeTrimNails = includeTrimNails;
        this.nailTrimCost = nailTrimCost;
        this.brushTeethCost =brushTeethCost;
    }
    
    //getter method for brushTeethCost variable
    public double getBrushTeethCost(){
        return this.brushTeethCost;
    }
    
    //setter method for brushTeethCost variable
    public void updateBrushTeethCost( double brushTeethCost){
        this.brushTeethCost = brushTeethCost;
    }
    
    //getter method for nailTrimCost variable
    public double getNailTrimCost(){
        return this.nailTrimCost;
    }
    //setter method for nailTrimCost variable
    public void updateNailTrimCost( double nailTrimCost){
        this.nailTrimCost = nailTrimCost;
    }
    
    //getter method for includeBrushTeeth
    public boolean includeBrushTeeth(){
        return this.includeBrushTeeth;
    }
    
    //getter method for includeTrimNails
    public boolean includeTrimNails(){
        return this.includeTrimNails;
    }
    
    //getTotalCost overide the super class getTotalCost Method
    @Override
    public double getTotalCost(){
        // create and  initialize local variable total with the Service Cost
        double total = this.getCost();
        //check if includeBrushTeeth value is true and add brushTeethCost to total
        if (this.includeBrushTeeth==true)
            total += this.brushTeethCost;
        //check if includeTrimNails value is true and add nailTrimCost to total
        if (this.includeTrimNails==true)
            total += this.nailTrimCost;
        
        return total; //return total
    }
    //toString

    @Override
    public String toString() {
        return "Cleaning services with " + this.getGroomer().getName();
    }
    
    
}
