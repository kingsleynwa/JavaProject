/*
 * Description: this is the Groomer.java class.
 * The Groomer class is designed to encapsulate key information relating to a 
 * specific Groomer. Every Groomer has a name and description/Speciality properties and this 
 * properties are initialize during the class creation
 * Created Date: 2021-07-07
 */
package rgu;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class Groomer {

    private String name;

    private String description;

    public Groomer(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
    
    //update groomer details this is not in the original code
    
    public void setName(String name) {
        this.name= name;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    

    @Override
    public String toString() {
        return "Groomer " + name + " is specialised in " + description;
    }
}
