/*
 * Description: this is the Booking class.
 * this class has service object, client and datetime as properties.
 * the class is used to create booking for a clients to a package.
 * this class implemnts the comparable interface that allows the current 
 * object to be compared with another.
 *
 * Created Date: 2021-07-06
 */
package rgu;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class Booking implements Comparable<Booking> {
    private final Service service;
    private final Client client;
    private final Date datetime;
    
    public Booking (Client client, Service service, Date datetime){
        this.client = client;
        this.service = service;
        this.datetime = datetime;
    }
    public Service getService(){
        return this.service;
    }
    public Client getClient(){
        return this.client;
    }
    public Date getDatetime(){
        return this.datetime;
    }
    @Override
    public String toString(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm a");
        return this.client.getName() + " for " + service.toString();
    }
     //formatting datetime as string
    public String getDatetimeAsString(){
        SimpleDateFormat formatter = new SimpleDateFormat("yyy-M-dd hh:mm");
	return formatter.format(this.datetime);
    }
    //implementing compareTo method from the comparable Interface
    @Override
    public int compareTo(Booking t) {
        return this.datetime.compareTo(t.datetime);
    }
//    @Override
//    public int compareTo(Booking t) {
//        return this.client.getName().compareTo(t.client.getName());
//    }
    
}
