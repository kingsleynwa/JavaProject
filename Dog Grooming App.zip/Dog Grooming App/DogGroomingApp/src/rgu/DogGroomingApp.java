/*
 * Description: this is the DogGroomingApp class.
 * this class is used to test the functionality of the project.
 * this class is runnable because it has the main method decleared in it
 * this class additional properties.
 * 
 * Created Date: 2021-07-06
 */
package rgu;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class DogGroomingApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {
        // TODO code application logic here
        
        //creating two groomers
        Groomer groomer1 = new Groomer("Andy", "Cleaning Dog");
        Groomer groomer2 = new Groomer("Jack", "Training Dog");
        //printing available groomers
        System.out.println("AVAILABLE GROOMERS");
        System.out.println(groomer1.toString());
        System.out.println(groomer2.toString());
        
        GroomingService service1 = new GroomingService ("Neaten", 200, "Grooming Service", groomer1, 350);
        GroomingService service2 = new GroomingService ("The Lion Cut", 250, "Groomin service", groomer2, 350);
        TrainingService service3 = new TrainingService (2, 150, "Training Service", groomer2, 100);
        CleaningService service4 = new CleaningService (true, false, 100, 80, "Cleaning Service", groomer1, 200);
        
        //Creating and Initializing to array list services
        ArrayList<Service> services = new ArrayList<Service>(){{
                                                add(service1);
                                                add(service2);
                                                add(service3);
                                                add(service4);
                                            }};
        System.out.println("LIST OF AVAILABLE SERVICES");
        //printing the available services
        services.forEach(s -> {
            System.out.println(s.toString());
        });
    
        System.out.println("LIST OF REGISTERED DOGS");
        //creating dog
        Dog dog1 = new Dog ("Fluffy", 3, DogBreed.POODLE);
        
        
        //printing dog
        System.out.println(dog1.toString());
        
        //creating a client
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        Client client1 = new Client ("Mr. Pius",sdf.parse("20-12-2020"),dog1);
        System.out.println("LIST OF REGISTERED CLIENTS");
        System.out.println(client1.toString());
        
        sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm a");
        Booking booking1 = new Booking (client1, service1, sdf.parse("10-07-2021 10:30 am"));
        Booking booking2 = new Booking (client1, service4, sdf.parse("10-07-2021 12:0 pm"));
        
        //create and initilize ArrayList Booking
        ArrayList<Booking> bookings = new ArrayList<Booking>(){{
                                                add(booking1);
                                                add(booking2);
                                            }};
        
        System.out.println("LIST OF BOKINGS MADE");
        bookings.forEach(b -> {
            System.out.println(b.toString());
        });
        System.out.println("CALCULATING BILLS FOR "+ client1.getName());
        //creating an object of the bookingUtil class
        BookingUtil bu = new BookingUtil();
        double package2Cost[] = bu.calculateBill(bookings, client1);
        
        System.out.printf("Total bill for %s: %2f \n", client1.getName(), package2Cost[0] );
        System.out.printf("Discounted bill for %s: %2f \n", client1.getName(), package2Cost[1] );
        
        //updating the cost price for service 1 from 350 to 500
        service1.updateCost(500);
        
        System.out.println("CALCULATING BILLS FOR "+ client1.getName());
        //recalsulating and printing the bills
        package2Cost = bu.calculateBill(bookings, client1);
        
        System.out.printf("Total bill for %s: %2f \n", client1.getName(), package2Cost[0] );
        System.out.printf("Discounted bill for %s: %2f \n", client1.getName(), package2Cost[1] );
    }
    
}
