/*
 * Description: this is the Dog.java class.
 * The Dog class is designed to encapsulate key information relating to a dog.
 * Every Dog has a name, age and breed properties and this properties are 
 * initialize during the class creation
 * Created Date: 2021-07-01
 */
package rgu;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class Dog {

    //instance variables of the clas Dog
    private final String name;
    private int age;
    private final DogBreed breed;

    //constructor method for Dog Class
    public Dog(String name, int age, DogBreed breed) {
        this.name = name;
        this.age = age;
        this.breed = breed;
    }

    //getter method name variable
    public String getName() {
        return this.name;
    }

    //getter method name variable
    public int getAge() {
        return this.age;
    }

    //getter method breed variable
    public DogBreed getBreed() {
        return this.breed;
    }

    //setter method for Age variable
    public void updateAge(int age) {
        this.age = age;
    }

    //override toString method to return a well formatted summary of the Class.
    @Override
    public String toString() {
        return this.name + " is a " + this.age + " years old " + this.breed + " dog"; //edit statement
    }
}
