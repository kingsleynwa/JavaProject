/*
 * Description: this is the BookingUtil class.
 * this class has only a single method call calculateBill.
 * calculateBill accept as parameter an arraylist of booking and a client object
 * the sum the total service cost for the particular client object. booking
 * calculate and sum the discounts for the client.
 * the method returns an array of double with two values (i.e the total Bill and
 * the discounted bill
 * 
 * Created Date: 2021-07-06
 */
package rgu;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class BookingUtil {

    public double[] calculateBill(ArrayList<Booking> b, Client c) {
        //creating and initializing array to be returned
        double[] total = {0, 0};
        //check the date joined

        Date joined = c.getJoined(); //date joined
        Date date = new Date();//todays date
        long diff_time = date.getTime() - joined.getTime();
        double diff_year = TimeUnit.MILLISECONDS
                .toDays(diff_time)
                / 365f;
        //iterate through the Booking list
        for (Booking b1 : b) {
            if (b1.getClient() == c) {
                total[0] += b1.getService().getTotalCost();
            }
        }

        //check if the joined year
        if (diff_year >= 2.5) {
            total[1] = total[0] - (0.15 * total[0]);
        } else {
            total[1] = total[0];
        }
        return total;
    }
}
