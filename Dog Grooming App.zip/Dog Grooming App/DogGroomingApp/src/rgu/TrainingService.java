/*
 * Description: this is the TrainingService.java class.
 * the class extends Service.jave abstract class.
 * The TrainingService class  includes basic wash and dry service.
 * Created Date: 2021-07-01
 */
package rgu;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class TrainingService extends Service{
    //creating instance variables
    private int sessions;
    private double sessionCost;
    
    //constructor method for the class
    
    public TrainingService(int sessions, double sessionCost, String description, Groomer groomer, double cost){
        super(description, groomer, cost);
        this.sessions = sessions;
        this.sessionCost = sessionCost;
    }
    
    public int getSessions(){
        return this.sessions;
    }
    public double getSessionCost(){
        return this.sessionCost;
    }
    public void updateSessionCost(double sessionCost){
        this.sessionCost = sessionCost;
    }
    public void updateSessions (int sessions){
        this.sessions = sessions;
    }
    @Override
    public double getTotalCost(){
        double total = this.getCost() + (sessions * sessionCost);
        return total;
    }
    
    @Override
    public String toString(){
         return "Training Service with " + this.getGroomer().getName();
    }
    
}
