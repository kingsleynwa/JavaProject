/*
 * Description: this is the DogBreed enum class.
 * Enum Class are collection of values of a property.
 * DogBreed class has Collection of Dog Breed stored.
 * Created Date: 2021-07-01
 */
package rgu;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public enum DogBreed {
    LABRADOR, POODLE, BEAGLE, DACHSHUND, PUG, CROSSBREED
}
