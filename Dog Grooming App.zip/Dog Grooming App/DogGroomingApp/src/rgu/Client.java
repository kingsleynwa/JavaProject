/*
 * Description: this is the Client.java class.
 * The Client class is designed to encapsulate key information relating to a 
 * specific Client. Every client has a name, Joined and dog properties and this 
 * properties are initialize during the class creation
 * Created Date: 2021-07-01
 */
package rgu;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public class Client {

    //creating instance variables
    private String name;
    private final Date joined;
    private final Dog dog;

    //constructor method for the class Client
    public Client(String name, Date joined, Dog dog) {
        this.name = name;
        this.joined = joined;
        this.dog = dog;
    }

    //getter method for name variable
    public String getName() {
        return this.name;
    }

    //getter method for dog variable
    public Dog getDog() {
        return this.dog;
    }

    //getter method for dog variable
    public Date getJoined() {
        return this.joined;
    }
    public void updateName(String name){
        this.name = name;
    }
    //toString method 
    //override toString method to return a well formatted summary of the Class.
    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return this.name + " is the owner of  " + this.dog.getName() + " joined date " + sdf.format(this.joined); //edit statement
    }

}
