/*
 * Description: this is the Service.java class
 * This class is decleare as Abstract class. 
 * Abstract class is a class that contains abtract method decleared in it.
 * Service class has the description, location and tourCost as its properties
 * Created Date: 2021-07-01
 */
package rgu;

/**
 *
 * @author Kingsley Nwabueze Osagie
 */
public abstract class Service {

    //creating instance variables of the class
    private final String description;
    private final Groomer groomer;
    private double cost;

    //creating constructor method
    public  Service(String description, Groomer groomer, double cost) {
        this.description = description;
        this.groomer = groomer;
        this.cost = cost;
    }

    //getter method for description variable
    public String getDescription() {
        return this.description;
    }
    
//getter methhod for groomer variable
    public Groomer getGroomer() {
        return this.groomer;
    }

    //getter method for cost variable
    public double getCost() {
        return this.cost;
    }

    //setter method for cost variable
    public void updateCost(double cost) {
        this.cost = cost;
    }
    
//abstract method getTotalcost
    public abstract double getTotalCost();

    @Override
    public String toString() {
        return description + " with " + groomer ;
    }

   
}
